
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyAOBrV6Xn3ggo8WUITKqJL11hEldzOAiH4",
  authDomain: "shoezweb.firebaseapp.com",
  projectId: "shoezweb",
  storageBucket: "shoezweb.appspot.com",
  messagingSenderId: "82619724437",
  appId: "1:82619724437:web:364a2a283d60d6e9f4219c",
  measurementId: "G-LRDQ67CFG6"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);
export const database = getFirestore(app);
const analytics = getAnalytics(app);
