import React, { useEffect } from 'react'
import img1 from "../assets/img1.png"
import Footer from './Footer'
import Navbar from './Navbar'

export default function Gallery({page,setPage,count}) {

    useEffect(() => {
        setPage('Gallery')
    })

    return (
        <div>
            <Navbar count={count} page={page} />
            <section id="gallery">
                <div class="h-primary">
                    <h1 class="h-style f-weight">Gallery</h1>
                </div>

                <div class="boxes">
                    <div class="box">
                        <img class="zoom" src={img1} alt="" />
                        <img class="zoom" src={img1} alt="" />
                        <img class="zoom" src={img1} alt="" />
                    </div>
                    <div class="box">
                        <img class="zoom" src={img1} alt="" />
                        <img class="zoom" src={img1} alt="" />
                        <img class="zoom" src={img1} alt="" />
                    </div>
                    <div class="box">
                        <img class="zoom" src={img1} alt="" />
                        <img class="zoom" src={img1} alt="" />
                        <img class="zoom" src={img1} alt="" />
                    </div>
                </div>

                <div id="imgBox" class="image-container">
                    <div id="caBox" class="carousel">
                        <img id="imagehover" alt="" />
                    </div>
                    <span id="cross" class="material-icons">close</span>
                    <i id="prev" class="fas fa-chevron-left"></i>
                    <i id="next" class="fas fa-chevron-right"></i>
                </div>
            </section>
            <Footer />
        </div>
    )
}
